/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.TilePane;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.scene.shape.Line;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


/**
 * FXML Controller class
 *
 * @author olibl
 */
public class MathGUIFXMLfxmlController implements Initializable {

    private TextField sievenumber;
    private TextField euclidnumbers;
    private TextField function;
    private TextField distancetwopoints;
    @FXML
    private TextField listarray;
    @FXML
    private TextField quadraticnumbers;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
@FXML
    private void sieveexcecute(ActionEvent event) throws IOException {
        String x="";
          String s=sievenumber.getText();
        int n= parseInt(s);
        boolean prime[]=new boolean[n+1];
        for(int i=0; i<n; i++)
        prime[i]=true;
        
        for (int p=2;p*p<=n;p++){
            if(prime[p]==true)
            {
                for(int i=p*p;i<=n;i+=p)
                    prime[i]=false;
                
            }
        }
        for(int i=2; i<=n;i++){
            if(prime[i]==true)
            x+=" "+i;
        }
            String message=("The primes are" +String.valueOf(x));
              Label secondLabel = new Label(message);
 
                StackPane secondaryLayout = new StackPane();
                secondaryLayout.getChildren().add(secondLabel);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(secondScene);
                newWindow.show();
    }
@FXML
    private void euclidexecute(ActionEvent event) {
        String s=euclidnumbers.getText();
        String []part=s.split(",");
        int a= parseInt(part[0]);
        int b=parseInt(part[1]);
         while (b>0){
        int temp=b;
        b=a%b;
        a=temp;
    }
     String message=("The GCD is "+a);
              Label secondLabel = new Label(message);
 
                StackPane secondaryLayout = new StackPane();
                secondaryLayout.getChildren().add(secondLabel);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(secondScene);
                newWindow.show();
}
      
@FXML
    private void functionexecute(ActionEvent event) {
        
        String formula=function.getText();
        
          if(!(formula.contains("x"))){
            throw new IllegalArgumentException("String " + formula + " does not contain a variable x");
        }
        String[] parts = formula.split("x");
        String a1 = parts[0];//+a or -a
        String b1 = parts[1];//+b or -b
        
        Boolean aPositive=true;
        Boolean bPositive=true;
        String a = "";
        int valueOfA = 0;
        String b = "";
        int valueOfB = 0;
        if(a1.contains("-")){
            aPositive=false;
            
        }
        a = a1.substring(1);
        valueOfA = Integer.parseInt(a);
        
        if(b1.contains("-")){
            bPositive=false;
            
        }
        b = b1.substring(1);
        valueOfB= Integer.parseInt(b);
        
        
        //Defining the x axis             
        NumberAxis xAxis = new NumberAxis(-50, 50, 10); 
        xAxis.setLabel("X-Axis"); 
        
        //Defining the y axis   
        NumberAxis yAxis = new NumberAxis(-50, 50, 10); 
        yAxis.setLabel("Y-Axis"); 
        
        //Creating the line chart 
        LineChart linechart = new LineChart(xAxis, yAxis);  
        
        //Prepare XYChart.Series objects by setting data 
        XYChart.Series series = new XYChart.Series(); 
        series.setName("Function f(x)="+formula); 
        
        double y=0;
        //populating the series with data
        for(double j=-50;j<51; j++){
            //calculate y
            if(aPositive && bPositive){
                y=valueOfA*j+valueOfB;
            }
            else if(!aPositive && bPositive){
                y=-1*valueOfA*j+valueOfB;
            }
            else if(aPositive && !bPositive){
                y=valueOfA*j-valueOfB;
            }
            else if(!aPositive && !bPositive){
                y=-1*valueOfA*j-valueOfB;
            }
            //create a new data point with x and y 
            series.getData().add(new XYChart.Data(j, y));
        }
        
        //Setting the data to Line chart    
        linechart.getData().add(series);        
        
        //hide the dots
        linechart.setCreateSymbols(false);
        
        //Creating a Group object  
        Group root = new Group(linechart); 

        //Creating a scene object 
        Scene scene = new Scene(root, 600, 400);  
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(scene);
                newWindow.show();
            //way to get back to the MathGUI
    }

        
@FXML
    private void distanceexecute(ActionEvent event) {
        
        String text = distancetwopoints.getText();
        String parts[]=text.split(",");
        String a = parts[0];
        String b = parts[1];
        String c = parts[2];
        String d = parts[3];
        int x1= Integer.parseInt(a);
        int y1= Integer.parseInt(b);
        int x2= Integer.parseInt(c);
        int y2= Integer.parseInt(d);
        int slope=(y2-y1)/(x2-x1);
         NumberAxis xAxis = new NumberAxis(-20, 20, 4); 
        xAxis.setLabel("X-Axis"); 
        
        //Defining the y axis   
        NumberAxis yAxis = new NumberAxis(-20,20,4); 
        yAxis.setLabel("Y-Axis"); 
        
        //Creating the line chart 
        LineChart linechart = new LineChart(xAxis, yAxis);  
        
        //Prepare XYChart.Series objects by setting data 
        XYChart.Series series = new XYChart.Series(); 
        series.setName("The distance between the points is "+Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))); 
 
              series.getData().add(new XYChart.Data(x1, y1));
              series.getData().add(new XYChart.Data(x2, y2));
        linechart.getData().add(series);        
        
        //hide the dots
        linechart.setCreateSymbols(true);
        
        //Creating a Group object  
        Group root = new Group(linechart); 
        Scene scene = new Scene(root, 600, 400);  
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(scene);
                newWindow.show();
    }
     
    @FXML
    private void opennotepad(ActionEvent event) {
        TextArea b= new TextArea();
         StackPane secondaryLayout = new StackPane();
         secondaryLayout.getChildren().add(b);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Notes");
                newWindow.setScene(secondScene);
                newWindow.show();
    }
    @FXML
    private void openmore(ActionEvent event) throws IOException {
       Parent root=FXMLLoader.load(getClass().getResource("Math2.fxml"));
            Scene scene= new Scene (root);
            
            Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
    }
@FXML
    private void backtomainmenu(ActionEvent event) throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("MainMenufinalFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
    }

    @FXML
    private void arrayexecute(ActionEvent event) {
        String decrease[];
          String numbers = listarray.getText();
        
        String[] split = numbers.split("\\s+");
        
        int out[] = new int[split.length]; 
        for(int i = 0 ; i < split.length ; i++){

             out[i] = Integer.parseInt(split[i]);
        }
        
        //sort increasing order
        int temp = 0;
        for(int i=0; i < out.length; i++){ 
            for(int j=1; j < (out.length-i); j++){  
                if(out[j-1] > out[j]){  
                //swap elements  
                    temp = out[j-1];  
                    out[j-1] = out[j];  
                    out[j] = temp;  
                }    
            }  
        }
        
        //mean of the array
        double sum = 0;
        for(int q=0; q<out.length; q++){
           sum+=out[q]; 
        }
        double mean = sum/out.length;
        String message=("The mean of the array is: " + mean);
        
        //highest number in the array
        int i; 
        int max = out[0];
        int maxIndex = 0;
        for (i = 1; i < out.length; i++) { 
            if (out[i] > max){
                max=out[i];
                maxIndex = i;
            }
        }
        String message2=("The highest number is " + max + " at index " + maxIndex);
        
        //standard deviation
        double stdDev = 0;
        ArrayList<Double> values = new ArrayList<Double>();
        double value;
        for(int z=0; z<out.length; z++){
            value = Math.pow(out[z]-mean, 2);
            values.add(value);
        }
        
        double summ = 0;
        for(int c = 0; c<out.length; c++){
            summ+=values.get(c);
        }
        double newMean = summ/out.length;
        stdDev = Math.sqrt(newMean);
        final double stdDevFinal = Math.round(stdDev*100.0)/100.0;
        String message3=("The standard deviation is " + stdDevFinal);
        String finalmessage=message+" "+message2+" "+message3;
        Label secondLabel = new Label(finalmessage);
 
                StackPane secondaryLayout = new StackPane();
                secondaryLayout.getChildren().add(secondLabel);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(secondScene);
                newWindow.show();
    }


    @FXML
    private void quadraticexecute(ActionEvent event) {
         String values =quadraticnumbers.getText();
    
        if(!(values.contains(","))){
            throw new IllegalArgumentException("a, b and c are not seperated by comma.");
        }
        
        String[] valuesList = values.split("\\s*,\\s*");
        
        String a = valuesList[0];
        String b = valuesList[1];
        String c = valuesList[2];
        
        int valueOfA = Integer.parseInt(a);
        int valueOfB = Integer.parseInt(b);
        int valueOfC = Integer.parseInt(c);
        
        double x1 = 0;
        double x2 = 0;
        double sqrtContent = Math.pow(valueOfB, 2)-(4*valueOfA*valueOfC);
        
        if(sqrtContent<0){
           String message=("the square root is negative, so there is no answer");
              Label secondLabel = new Label(message);
 
                StackPane secondaryLayout = new StackPane();
                secondaryLayout.getChildren().add(secondLabel);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(secondScene);
                newWindow.show();
        }
        else{
        x1 = (valueOfB*(-1)+Math.sqrt(sqrtContent))/(2*valueOfA);
        x2 = (valueOfB*(-1)-Math.sqrt(sqrtContent))/(2*valueOfA);
        
        //round to 2 decimals
        final double x1Final = Math.round(x1*100.0)/100.0;
        final double x2Final = Math.round(x2*100.0)/100.0;
        
        String message=("the values of x are: " + x1Final + " and " + x2Final);
              Label secondLabel = new Label(message);
 
                StackPane secondaryLayout = new StackPane();
                secondaryLayout.getChildren().add(secondLabel);
                Scene secondScene = new Scene(secondaryLayout, 230, 100);
                Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(secondScene);
                newWindow.show();
        }  
    }


    @FXML
    private void backtoMath(ActionEvent event) throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("MathGUIFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
    }
    
}
