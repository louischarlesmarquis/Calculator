/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

/**
 *
 * @author olibl
 */
public class Energy {
    private double mass;
    private double velocity;
    private double height;
    private double kinetic;
    private double potential;
    private double work;
    private static double gravity = 9.81;
    public Energy(double mass,double velocity,double height,double work){
        this.height=height;
        this.mass=mass;
        this.velocity=velocity;
        this.work=work;
        
        
    }
    
    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public double getVelocity() {
        return velocity;
    }

    public void setVelocity(double velocity) {
        this.velocity = velocity;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getKinetic() {
        return kinetic;
    }

    public void setKinetic(double kinetic) {
        this.kinetic = kinetic;
    }

    public double getPotential() {
        return potential;
    }

    public void setPotential(double potential) {
        this.potential = potential;
    }

    public double getWork() {
        return work;
    }

    public void setWork(double work) {
        this.work = work;
    }
    public double getGravity() {
        return gravity;
    }
    
    public double calculateWork(){
        double energyWork = (0.5*(mass*velocity*velocity)) + (mass*gravity*height);
        
     return(energyWork);   
    }
    public double calculateMass(){
        double weight = work/((gravity*height)+(0.5*velocity*velocity));
        
     return(weight);   
    }
    public double calculateVelocity(){
        double potentialEnergy;
        if(potential == 0){
            potentialEnergy= calculatePotential();
        }
        else{
            potentialEnergy= potential;
        }
        double velocities= Math.sqrt((2*(work - potentialEnergy))/(mass));
         
        
     return(velocities);   
    }
    public double calculateHeight(){
        
        double kineticEnergy;
        if(kinetic == 0){
            kineticEnergy= calculateKinetic();
        }
        else{
            kineticEnergy= kinetic;
        }
        double heights= (work - kineticEnergy)/(gravity*mass);
        
        
     return(heights);   
    }
    public double calculateKinetic(){
        double kineticEnergy =(0.5*(mass*velocity*velocity));
        
     return(kineticEnergy);   
    }
    public double calculatePotential(){
        double potentialEnergy =(mass*gravity*height);
        
     return(potentialEnergy);   
    }
}
