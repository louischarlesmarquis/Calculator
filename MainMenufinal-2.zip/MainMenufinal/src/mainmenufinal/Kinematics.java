/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

/**
 *
 * @author olibl
 */
public class Kinematics {
        private double initialVelocity;
    private double finalVelocity;
    private double acceleration;
    private double distance;
    private double time;
    public Kinematics(double initalVelocity, double distance, double finalVelocity,double acceleration, double time) {
        this.initialVelocity = initalVelocity;
        this.finalVelocity = finalVelocity;
        this.acceleration = acceleration;
        this.distance = distance;
        this.time = time;
    }
    
    
    

    public double getInitalVelocity() {
        return initialVelocity;
    }

    public void setInitalVelocity(double initalVelocity) {
        this.initialVelocity = initalVelocity;
    }

    public double getFinalVelocity() {
        return finalVelocity;
    }

    public void setFinalVelocity(double finalVelocity) {
        this.finalVelocity = finalVelocity;
    }

    public double getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }
   public void calculate(int formulaSelect){
       
       double x=0;
       double y =0;
        switch(formulaSelect) {
    case 6 :
        //quadratic
        x = finalVelocity - acceleration*time;
        this.setInitalVelocity(x);
        y = finalVelocity*time - (0.5*acceleration*time*time);
        
        this.setDistance(y);
        break; 
   
    case 10 :
        x = (distance - acceleration*time*time)/time;
        
        this.setInitalVelocity(x);
        y = initialVelocity + acceleration*time;
        this.setFinalVelocity(y);
        break; 
    case 14:
        x= (2*distance/time) -finalVelocity;
        this.setInitalVelocity(x);
        y = (initialVelocity-finalVelocity)/time;
  
        this.setAcceleration(y);
        break;
    case 22:
        x = Math.sqrt(finalVelocity*finalVelocity-2*acceleration*distance);
        this.setInitalVelocity(x);
        y = (initialVelocity-finalVelocity)/acceleration;
    
        this.setTime(y);
        break;    
    case 15:
        x = initialVelocity + acceleration*time;
        this.setFinalVelocity(x);
        y = finalVelocity*time - 0.5*acceleration*time*time;
        
        this.setDistance(y);
        break;
    case 21:
        x=(finalVelocity - initialVelocity)/time;
        this.setAcceleration(x);
        y = finalVelocity*time - 0.5*acceleration*time*time;
        
        this.setDistance(y);
        break;
    case 33:
        x = (initialVelocity-finalVelocity)/acceleration;
        this.setTime(x);
        y = finalVelocity*time - 0.5*acceleration*time*time;
        
        this.setDistance(y);
        break;    
    case 35:
        x= (2*distance/time) - initialVelocity;
        this.setFinalVelocity(x);
        y = (initialVelocity-finalVelocity)/time;
        
        this.setDistance(y);
        break; 
    case 55:
        x = Math.sqrt(initialVelocity*initialVelocity-2*acceleration*distance);
        this.setFinalVelocity(x);
        y = (initialVelocity-finalVelocity)/acceleration;
        
        this.setTime(y);
        break;
    case 77:
        x = (finalVelocity*finalVelocity + initialVelocity*initialVelocity)/2*time;
        this.setAcceleration(x);
        y = (initialVelocity-finalVelocity)/acceleration;
        
        this.setTime(y);
        
        break;
     default : 
      
}
   }
}
