/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author olibl
 */
public class CalculatorFXMLController implements Initializable {

    @FXML
    private Button seven;
    @FXML
    private Button eight;
    @FXML
    private Button nine;
    @FXML
    private Button division;
    @FXML
    private Button four;
    @FXML
    private Button five;
    @FXML
    private Button six;
    @FXML
    private Button minus;
    @FXML
    private Button three;
    @FXML
    private Button two;
    @FXML
    private Button one;
    @FXML
    private Button multiplication;
    @FXML
    private Button zero;
    @FXML
    private Button equal;
    @FXML
    private Button plus;
    @FXML
    private Button Clear;
    @FXML
    private Button cuberoot;
    @FXML
    private Button exponent;
    @FXML
    private Button sqrt;
    @FXML
    private Button factorial;
    @FXML
     private Button point;
    
     Float data=0f;
    int operation=-1;
    @FXML
    private TextField tfresult;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void backtomain(ActionEvent event) throws IOException {
         Parent root=FXMLLoader.load(getClass().getResource("MainMenufinalFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if(event.getSource()==one){
           tfresult.setText(tfresult.getText()+"1");
        }
        else if(event.getSource()==two){
           tfresult.setText(tfresult.getText()+"2");
        }
       else if(event.getSource()==three){
           tfresult.setText(tfresult.getText()+"3");
        }
       else if(event.getSource()==four){
           tfresult.setText(tfresult.getText()+"4");
        }
       else if(event.getSource()==five){
           tfresult.setText(tfresult.getText()+"5");
        }
       else if(event.getSource()==six){
           tfresult.setText(tfresult.getText()+"6");
        }
       else if(event.getSource()==seven){
           tfresult.setText(tfresult.getText()+"7");
        }
       else if(event.getSource()==eight){
           tfresult.setText(tfresult.getText()+"8");
        }
       else if(event.getSource()==nine){
           tfresult.setText(tfresult.getText()+"9");
        }
       else if(event.getSource()==zero){
           tfresult.setText(tfresult.getText()+"0");
        }
         
        else if(event.getSource()==point){
           tfresult.setText(tfresult.getText()+".");
        }
        if(event.getSource()==Clear){
            tfresult.setText("");
        }
        else if(event.getSource()==plus){
            data=Float.parseFloat(tfresult.getText());
            operation=1;
            tfresult.setText("");
        }
        else if(event.getSource()==minus){
            data=Float.parseFloat(tfresult.getText());
            operation=2;
            tfresult.setText("");
        }
        else if(event.getSource()==multiplication){
            data=Float.parseFloat(tfresult.getText());
            operation=3;
            tfresult.setText("");
        }
        else if(event.getSource()==division){
            data=Float.parseFloat(tfresult.getText());
            operation=4;
            tfresult.setText("");
        }
       
         else if(event.getSource()==exponent){
            data=Float.parseFloat(tfresult.getText());
            operation=5;
            tfresult.setText("");
        }
         if(event.getSource()==equal){
            Float secondOperand=Float.parseFloat(tfresult.getText());
            switch(operation){
                case 1 -> {
                    Float ans= data+secondOperand;
                    tfresult.setText(String.valueOf(ans));
                }
                case 2 -> {
                    Float ans = data-secondOperand;
                    tfresult.setText(String.valueOf(ans));
                }
                case 3 -> {
                    Float ans = data*secondOperand;
                    tfresult.setText(String.valueOf(ans));
                }
                case 4 -> {
                    Float ans = 0f;
                        ans= data/secondOperand;
                        if(secondOperand==0)
                            tfresult.setText("Error");                  
                        else
                    tfresult.setText(String.valueOf(ans));
                }
                case 5 -> {
                   Float ans = (float)Math.pow(data, secondOperand);
                    tfresult.setText(String.valueOf(ans));
                }
                
            }
        }
    }
    }
   
