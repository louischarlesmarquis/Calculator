/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

/**
 *
 * @author olibl
 */
public class HeatContent {
     private double mass;
    private double heatEnergy;
    private double capacity;
    private double initialTemp;
    private double finalTemp;

    public HeatContent(double mass, double heatEnergy,double capacity,double initalTemp,double finalTemp){
        this.mass = mass;
        this.capacity= capacity;
        this.heatEnergy= heatEnergy;
        this.initialTemp= initalTemp;
        this.finalTemp= finalTemp;
                
    }
    public double getInitialTemp() {
        return initialTemp;
    }

    public void setInitialTemp(double initialTemp) {
        this.initialTemp = initialTemp;
    }

    public double getFinalTemp() {
        return finalTemp;
    }

    public void setFinalTemp(double finalTemp) {
        this.finalTemp = finalTemp;
    }
    public double calculateCapacity(){
        double capacity =(heatEnergy/(mass*(finalTemp - initialTemp)));
        
        
        return capacity;
    }
    public double calculateHeatEnergy(){
        double Energy = mass*capacity*(finalTemp-initialTemp);
        
        return Energy;
    }
    public double calculateMass(){
        double theMass =(heatEnergy/(capacity*(finalTemp - initialTemp)));
        
        return theMass;
        
    }
    public double calculateInitialTemperature(){
        double ITemperature = -(heatEnergy/capacity*mass) + finalTemp;
        
        return ITemperature;
        
    }
    public double calculateFinalTemperature(){
        double FTemperature = (heatEnergy/capacity*mass) + initialTemp;
        
        return FTemperature;
    }
    public double calculateDeltaTemperature(){
        double deltaTemperature = (finalTemp - initialTemp);
        
        return deltaTemperature;
    }


}
