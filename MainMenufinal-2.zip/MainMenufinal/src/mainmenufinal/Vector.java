/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

/**
 *
 * @author olibl
 */
public class Vector {
      private double magnitude;
    private double angle;
    private double Xvector ;
    private double Yvector ;
    
    
    public Vector(double magnitude, double angle){
        this.angle=angle;
        this.magnitude=magnitude;
    }
    
    public double getAngle(){
        return(angle);
    }
    public double getMagnitude(){
        return(magnitude);
    }
    public void calculateXandYvector(){
        if(angle==270 || angle ==90){
            Xvector=0;
        }
        else{
        Xvector = magnitude*(Math.cos(Math.toRadians(angle)));
        }
        if(angle==0 || angle ==180){
            Yvector=0;
        }
        else{
        Yvector = magnitude*(Math.sin(Math.toRadians(angle)));
        }
        // ((angle*Math.PI)/180)
    }
    
    public void setAngle(double angle){
        this.angle = angle;
    }
    public void setMagnitude(double magnitude){
        this.magnitude=magnitude;
    }
    public double getXvector(){
        return(Xvector);
    }
    public double getYvector(){
        return(Yvector);
    }
    public Vector add(Vector x){
        double angleResultant;
        double Xaxis=(x.getXvector() + this.Xvector);
        
        double Yaxis=(x.getYvector() + this.Yvector);
        
        double resultant = Math.sqrt(((Xaxis*Xaxis) + (Yaxis*Yaxis)));
        if(Xaxis ==0){
            if(Yaxis > 0){
                angleResultant=90;
            }
            else 
                angleResultant = 270;
        }
        else{
            angleResultant = Math.toDegrees((Math.atan((Yaxis/Xaxis))));
        }
        double sectorNumber=angle +x.getAngle(); 
        if(sectorNumber > 180 && sectorNumber != 540){
            if(sectorNumber < 360){
              angleResultant =  angleResultant+180;
            }
            else if(sectorNumber == 360){
                angleResultant =  180;
            }
            else if(sectorNumber <= 540){
                angleResultant =  angleResultant+180;
            }
            else if(sectorNumber <= 720){
                angleResultant =  angleResultant+360;
            }
        }
        
        
        Vector a = new Vector(resultant,angleResultant);
        return(a);
    } 
}
