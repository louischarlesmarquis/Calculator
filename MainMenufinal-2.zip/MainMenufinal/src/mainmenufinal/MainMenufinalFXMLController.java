/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author olibl
 */
public class MainMenufinalFXMLController implements Initializable {

    @FXML
    private Button MathButton;
    @FXML
    private Button PhysicsButton;
    @FXML
    private Button ChemsitryButton;
    @FXML
    private Button CalculatorButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void GOMathGUI(ActionEvent event) throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("MathGUIFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage window= (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(scene);
            window.show();
    }

    @FXML
    private void GOPhysicsGUI(ActionEvent event) throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("PhysicsGUIFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(scene);
                newWindow.show();
    }

    @FXML
    private void GOChemistryGUI(ActionEvent event) throws IOException {
        Parent root=FXMLLoader.load(getClass().getResource("ChemistryGUIFXML.fxml"));
            Scene scene= new Scene (root);
            
            Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(scene);
                newWindow.show();
    }

    @FXML
    private void GoCalculator(ActionEvent event) throws IOException {
            Parent root=FXMLLoader.load(getClass().getResource("CalculatorFXML.fxml"));
            Scene scene= new Scene (root);
             Stage newWindow = new Stage();
                newWindow.setTitle("Second Stage");
                newWindow.setScene(scene);
                newWindow.show();
        }
    


    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }
    
}
