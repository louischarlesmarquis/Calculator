/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;

/**
 *
 * @author olibl
 */
public class Pressure {
    private double moles;
    private double pressure;
    private double volume;
    private double temperature;
    private double gasConstant;
    
    public Pressure(double volume, double pressure, double moles, double temperature,double gasConstant){
        this.moles=moles;
        this.pressure=pressure;
        this.volume= volume;
        this.temperature = temperature;
        this.gasConstant = gasConstant;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    public double getPressure() {
        return pressure;
    }

    public void setPressure(double pressure) {
        this.pressure = pressure;
    }

    public double getMoles() {
        return moles;
    }

    public void setMoles(double moles) {
        this.moles = moles;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getGasConstant() {
        return gasConstant;
    }

    public void setGasConstant(double gasConstant) {
        this.gasConstant = gasConstant;
    }
    public double calculatePressure(){
        double pressureVal =(moles*gasConstant*temperature)/volume;
        
        return(pressureVal);
        
    }
    public double calculateVolume(){
        double volumeVal =  (moles*gasConstant*temperature)/pressure;
        
        return(volumeVal);
        
    }
    public double calculateTemperature(){
        double temperatureVal =((pressure*volume)/(moles*gasConstant));
        
        return(temperatureVal);
        
    }
    public double calculateMoles(){
        double molesVal = ((pressure*volume)/(temperature*gasConstant));
        
        return(molesVal);
        
    }
    public double calculateRConstant(){
        double rConstant = ((pressure*volume)/(temperature*moles));
        
        return(rConstant);
        
    }
}
