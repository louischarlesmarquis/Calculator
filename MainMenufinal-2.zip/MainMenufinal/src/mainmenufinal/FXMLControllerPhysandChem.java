/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainmenufinal;
import java.io.IOException;
import java.util.Hashtable;
import java.util.InputMismatchException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FXMLControllerPhysandChem  {
    @FXML public Button KinematicsGUI ;
    @FXML public Button VectorGUI;
    @FXML public Button EnergyGUI;
    @FXML
    void backtoPhysics(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("PhysicsGUIFXML.fxml"));
        Scene Scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow(); 
        stage.setScene(Scene);
        stage.show();
    }
    public void KinematicsGUI (ActionEvent event)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("Kinematics.fxml"));
        Scene kinematicScene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow(); 
        stage.setScene(kinematicScene);
        stage.show();
    }
     @FXML
    private TextField IniVelo;

    @FXML
    private TextField FinalVelo;

    @FXML
    private TextField Dist;

    @FXML
    private TextField Accel;

    @FXML
    private TextField Time;

    @FXML
    private TextField errorBoxKinematic;

    @FXML
    private ToggleButton exampleKinematic;

    @FXML
    void Kinematics(ActionEvent event) {
        int counter =0;
        int missingVar =1;
        try{
            if(!(IniVelo.getText().equals(""))){
                Double.parseDouble(IniVelo.getText());
                counter++;
            }
            else
               missingVar= missingVar*2;
            if(!(Dist.getText().equals(""))){
                Double.parseDouble(Dist.getText());
                counter++;
            }
            else
                missingVar= missingVar*3;
            if(!(FinalVelo.getText().equals(""))){
                Double.parseDouble(FinalVelo.getText());
                counter++;
            }
            else
                missingVar= missingVar*5;
            if(!(Accel.getText().equals(""))){
                Double.parseDouble(Accel.getText());
                counter++;
            }
             
            else
                missingVar= missingVar*7;
            if(!(Time.getText().equals(""))){
                Double.parseDouble(Time.getText());
                counter++;
            }
             
            else
                missingVar= missingVar*11;
            if(counter != 3)
            throw new InputMismatchException();
        
            switch(missingVar) {
                case 6 :
                 Kinematics a = new Kinematics(0,0,Double.parseDouble(FinalVelo.getText()),
                         Double.parseDouble(Accel.getText())
                         ,Double.parseDouble(Time.getText()));
                         a.calculate(6);
                         IniVelo.setText(""+a.getInitalVelocity());
                    Dist.setText(""+a.getDistance());
                break; 
                case 10 :
                    Kinematics b = new Kinematics(0,Double.parseDouble(Dist.getText()),0,
                            Double.parseDouble(Accel.getText()),
                            Double.parseDouble(Time.getText()));
                    b.calculate(10);
                    IniVelo.setText(""+b.getInitalVelocity());
                    FinalVelo.setText(""+b.getFinalVelocity());
                break; 
                case 14:
                    Kinematics c = new Kinematics(0,Double.parseDouble(Dist.getText()),
                            Double.parseDouble(FinalVelo.getText()),0,
                            Double.parseDouble(Time.getText()));
                    c.calculate(14);
                    IniVelo.setText(""+c.getInitalVelocity());
                    Accel.setText(""+c.getAcceleration ());
        
                break;
                case 22:
                    Kinematics d = new Kinematics(0,Double.parseDouble(Dist.getText()),
                            Double.parseDouble(FinalVelo.getText()),
                            Double.parseDouble(Accel.getText()),0);
                    d.calculate(22);
                    IniVelo.setText(""+d.getInitalVelocity());
                    Time.setText(""+d.getTime());
        
                break;    
                case 15:
                    Kinematics e = new Kinematics(Double.parseDouble(IniVelo.getText())
                            ,0,0,Double.parseDouble(Accel.getText())
                            ,Double.parseDouble(Time.getText()));
                            e.calculate(15);
                            FinalVelo.setText(""+e.getFinalVelocity());
                    Dist.setText(""+e.getDistance());
                break;
                case 21:
                    Kinematics f = new Kinematics(Double.parseDouble(IniVelo.getText())
                            ,0,Double.parseDouble(FinalVelo.getText()),0,
                            Double.parseDouble(Time.getText()));
                    f.calculate(21);
                    Dist.setText(""+f.getDistance());
                    Accel.setText(""+f.getAcceleration());
        
                break;
                case 33:
                    Kinematics g = new Kinematics(Double.parseDouble(IniVelo.getText()),0,
                            Double.parseDouble(FinalVelo.getText()),
                            Double.parseDouble(Accel.getText()),0);
                    g.calculate(33);
                    Dist.setText(""+g.getDistance());
                    Time.setText(""+g.getTime());
        
                break;    
                case 35:
                    Kinematics h = new Kinematics(Double.parseDouble(IniVelo.getText()),
                            Double.parseDouble(Dist.getText()),0,0,
                    Double.parseDouble(Time.getText()));
                    h.calculate(35);
                    FinalVelo.setText(""+h.getFinalVelocity());
                    Accel.setText(""+h.getAcceleration());
        
                break; 
                case 55:
                    Kinematics i = new Kinematics(Double.parseDouble(IniVelo.getText()),
                            Double.parseDouble(Dist.getText()),
                            0,Double.parseDouble(Accel.getText()),0);
                    i.calculate(55);
                    FinalVelo.setText(""+i.getFinalVelocity());
                    Time.setText(""+i.getTime());
       
                break;
                case 77:
                    Kinematics j = new Kinematics(Double.parseDouble(IniVelo.getText()),
                            Double.parseDouble(Dist.getText()),
                            Double.parseDouble(FinalVelo.getText()),0,0);
                    j.calculate(77);
                    Accel.setText(""+j.getAcceleration());
                    Time.setText(""+j.getTime());
               
                break;

                default: throw new InputMismatchException();
            }
        }
        catch(InputMismatchException | NumberFormatException e){
            errorBoxEnergy.setText("Input was not a number Or Not enough inputs to calculate");
        }
    }

    @FXML
    void onToggleKinematicEx(ActionEvent event) {

    }

    public void EnergyGUI(ActionEvent eventEnergy)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("Energy.fxml"));
        Scene energyScene = new Scene(root);
        Stage stage = (Stage) ((Node)eventEnergy.getSource()).getScene().getWindow(); 
        stage.setScene(energyScene);
        stage.show();
    }
    
    //Energy pane
    @FXML
    private TextField Mass;

    @FXML
    private TextField Velocity;

    @FXML
    private TextField Height;

    @FXML
    private TextField Kinetic;

    @FXML
    private TextField Potential;

    @FXML
    private TextField Work;

    @FXML
    private TextField errorBoxEnergy;

    @FXML
    private ToggleButton exampleEnergy;

    @FXML
    void Energy() {
     int counter =0;
        int missingVar =6;
        try{
            if(!(Mass.getText().equals(""))){
                Double.parseDouble(Mass.getText());
                counter++;
            }
            else
                missingVar =1;
            if(!(Velocity.getText().equals(""))){
                Double.parseDouble(Velocity.getText());
                counter++;
            }
            else
                missingVar =2;
            if(!(Height.getText().equals(""))){
                Double.parseDouble(Height.getText());
                counter++;
            }
            else
                missingVar =3;
            if(!(Work.getText().equals(""))){
                Double.parseDouble(Work.getText());
                counter++;
            }
             
            else
                missingVar =4;
            if(counter !=3)
            throw new InputMismatchException();
        
            switch(missingVar) {
                case 1:
                    Energy missingMass= new Energy(0.0,
                            Double.parseDouble(Velocity.getText()),
                    Double.parseDouble(Height.getText()),Double.parseDouble(Work.getText()));
                         Work.setText(""+missingMass.calculateMass());
                    break;
                case 2:
                    Energy missingVelocity= new Energy(
                           Double.parseDouble(Mass.getText()),0.0,
                    Double.parseDouble(Height.getText()),Double.parseDouble(Work.getText()));
                         Work.setText(""+missingVelocity.calculateVelocity());
                    break;
                case 3:
                    Energy missingHeight= new Energy(
                           Double.parseDouble(Mass.getText()),Double.parseDouble(Velocity.getText()),
                    0.0,Double.parseDouble(Work.getText()));
                         Work.setText(""+missingHeight.calculateHeight());
                    break;
                case 4:
                    Energy missingWork= new Energy(
                           Double.parseDouble(Mass.getText()),Double.parseDouble(Velocity.getText()),
                    Double.parseDouble(Height.getText()),0.0);
                         Work.setText(""+missingWork.calculateWork());
                    break;
                default: throw new InputMismatchException();
            }
        }
        catch(InputMismatchException | NumberFormatException e){
            errorBoxEnergy.setText("Input was not a number Or Not enough inputs to calculate");
        }
        
    }
    

    @FXML
    void onToggleEnergyEx(ActionEvent event) {

    }
    //forcesPane Starting point
    public void VectorGUI(ActionEvent eventForce)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("VectorForce.fxml"));
        Scene ForceScene = new Scene(root);
        Stage stage = (Stage) ((Node)eventForce.getSource()).getScene().getWindow(); 
        stage.setScene(ForceScene);
        stage.show();
    }
    @FXML
    private TextField mag1;

    @FXML
    private TextField angle1;

    @FXML
    private TextField mag2;

    @FXML
    private TextField angle2;


    @FXML
    private TextField errorBoxForce;
    
    @FXML
    private TextField answerforce;

    @FXML
    private ToggleButton exampleForce;

    @FXML
    void VectorForce() {
        //force calculations
        int counter =0;
        
        try{
            if(!(mag1.getText().equals(""))){
                Double.parseDouble(mag1.getText());
                counter++;
            }
            if(!(angle1.getText().equals(""))){
                Double.parseDouble(angle1.getText());
                counter++;
            }
            if(!(mag2.getText().equals(""))){
                Double.parseDouble(mag2.getText());
                counter++;
            }
            if(!(angle2.getText().equals("") )){
                Double.parseDouble(angle2.getText());
                counter++;
            }
            if(counter != 4)
            throw new InputMismatchException();
        
            Vector force1 = new Vector(Double.parseDouble(mag1.getText()),Double.parseDouble(angle1.getText()));  
            Vector force2 = new Vector(Double.parseDouble(mag2.getText()),Double.parseDouble(angle2.getText()));
            force1.calculateXandYvector();
            force2.calculateXandYvector();
            Vector answer =force1.add(force2);
            answerforce.setText("Magnitude is : "+answer.getMagnitude()+" Angle is : "+answer.getAngle());
        }
        catch(InputMismatchException | NumberFormatException e){
            errorBoxForce.setText("Input was not a number Or Not enough inputs to calculate");
        }
    }
     @FXML
    void onReturnForce(ActionEvent eventPhysics) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("Physics_Pane.fxml"));
        Scene PhysicsScene = new Scene(root);
        Stage stage = (Stage) ((Node)eventPhysics.getSource()).getScene().getWindow(); 
        stage.setScene(PhysicsScene);
        stage.show();
        //back button for forces pane
    }

    @FXML
    void onToggleForceEx(ActionEvent event) {

    }

    //chemistrystartpane
    @FXML
    private Button heatButton;

    @FXML
    private Button PressureButton;

    @FXML
    void HeatContentGUI (ActionEvent eventHeat) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("HeatContent.fxml"));
        Scene HeatScene = new Scene(root);
        Stage stage = (Stage) ((Node)eventHeat.getSource()).getScene().getWindow(); 
        stage.setScene(HeatScene);
        stage.show();
    }
    //Heat Content Pane
    @FXML
    private TextField MassHC;

    @FXML
    private TextField IniTemp;

    @FXML
    private TextField Capacity;

    @FXML
    private TextField HeatEnergy;

    @FXML
    private TextField FinalTemp;

    @FXML
    private TextField errorBoxHeat;

    @FXML
    private ToggleButton HeatExample;

    @FXML
    public void HeatContent() {
        int counter =0;
        int missingVar =6;
        try{
            if(!(MassHC.getText().equals(""))){
                Double.parseDouble(MassHC.getText());
                counter++;
            }
            else
                missingVar =1;
            if(!(Capacity.getText().equals(""))){
                Double.parseDouble(Capacity.getText());
                counter++;
            }
            else
                missingVar =2;
            if(!(HeatEnergy.getText().equals(""))){
                Double.parseDouble(HeatEnergy.getText());
                counter++;
            }
            else
                missingVar =3;
            if(!(IniTemp.getText().equals("") )){
                Double.parseDouble(IniTemp.getText());
                counter++;
            }
            else
                missingVar =4;
            if(!(FinalTemp.getText().equals(""))){
                Double.parseDouble(FinalTemp.getText());
                counter++;
            }
             
            else
                missingVar =5;
            if(counter != 4)
            throw new InputMismatchException();
        
            switch(missingVar) {
                case 1:
                    HeatContent missingMass= new HeatContent(
                        0.0,Double.parseDouble(HeatEnergy.getText()),
                    Double.parseDouble(Capacity.getText()),Double.parseDouble(IniTemp.getText()),
                           Double.parseDouble(FinalTemp.getText()));
                    
                         MassHC.setText(""+missingMass.calculateMass());
                            
                
                    break;
                case 2:
                    HeatContent missingCapacity= new HeatContent(
                            Double.parseDouble(MassHC.getText()),Double.parseDouble(HeatEnergy.getText()),
                    0.0,Double.parseDouble(IniTemp.getText()),
                           Double.parseDouble(FinalTemp.getText()));
                         Capacity.setText(""+missingCapacity.calculateCapacity());
                    break;
                case 3:
                    HeatContent missingEnergy= new HeatContent(
                            Double.parseDouble(MassHC.getText()),0.0,
                    Double.parseDouble(Capacity.getText()),Double.parseDouble(IniTemp.getText()),
                           Double.parseDouble(FinalTemp.getText()));
                         HeatEnergy.setText(""+missingEnergy.calculateHeatEnergy());
                         
                    break;
                case 4:
                    HeatContent missingITemp= new HeatContent(
                           Double.parseDouble(MassHC.getText()),Double.parseDouble(HeatEnergy.getText()),
                    Double.parseDouble(Capacity.getText()),0.0,
                           Double.parseDouble(FinalTemp.getText()));
                         IniTemp.setText(""+missingITemp.calculateInitialTemperature());
                    break;
                case 5:
                    HeatContent missingFTemp= new HeatContent(
                            Double.parseDouble(MassHC.getText()),Double.parseDouble(HeatEnergy.getText()),
                    Double.parseDouble(Capacity.getText()),Double.parseDouble(IniTemp.getText()),
                           0.0);
                         FinalTemp.setText(""+missingFTemp.calculateFinalTemperature());
                    break;
                default: throw new InputMismatchException(); 
            }
        }
        catch(InputMismatchException | NumberFormatException e){
            errorBoxEnergy.setText("Input was not a number Or Not enough inputs to calculate");
        }
    }
    
    @FXML
    void onToggleHeatEX(ActionEvent event) {

    }
    @FXML
    void backtoChemistry(ActionEvent event) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("ChemistryGUIFXML.fxml"));
        Scene Scene = new Scene(root);
        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow(); 
        stage.setScene(Scene);
        stage.show();
        //back button for the menu chemisrty
    }
   
    @FXML
    void PressureGUI(ActionEvent eventPressure) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("PressureLaws.fxml"));
        Scene PressureScene = new Scene(root);
        Stage stage = (Stage) ((Node)eventPressure.getSource()).getScene().getWindow(); 
        stage.setScene(PressureScene);
        stage.show();
    } 
    //Pressure pane
    @FXML
    private TextField Pressure;

    @FXML
    private TextField Volume;


    @FXML
    private TextField RConstant;

    @FXML
    private TextField Temperature;

    @FXML
    private TextField Moles;

    @FXML
    private TextField errorBoxGas;

    @FXML
    private ToggleButton idealGasExample;

    @FXML
    void PressureLaws() {
        int counter =0;
        int missingVar =6;
        try{
            if(!(Pressure.getText().equals(""))){
                Double.parseDouble(Pressure.getText());
                counter++;
            }
            else
                missingVar =1;
            if(!(Volume.getText().equals(""))){
                Double.parseDouble(Volume.getText());
                counter++;
            }
            else
                missingVar =2;
            if(!(RConstant.getText().equals(""))){
                Double.parseDouble(RConstant.getText());
                counter++;
            }
            else
                missingVar =3;
            if(!(Temperature.getText().equals("") )){
                Double.parseDouble(Temperature.getText());
                counter++;
            }
            else
                missingVar =4;
            if(!(Moles.getText().equals(""))){
                Double.parseDouble(Moles.getText());
                counter++;
            }
             
            else
                missingVar =5;
            if(counter != 4)
            throw new InputMismatchException();
        
            switch(missingVar) {
                case 1:
                    Pressure missingPressure= new Pressure(
                            Double.parseDouble(Volume.getText()),0.0,
                    Double.parseDouble(Moles.getText()),Double.parseDouble(Temperature.getText()),
                           Double.parseDouble(RConstant.getText()));
                    
                         Pressure.setText(""+missingPressure.calculatePressure());
                            
                
                    break;
                case 2:
                    Pressure missingVolume= new Pressure(
                            0.0,Double.parseDouble(Pressure.getText()),
                    Double.parseDouble(Moles.getText()),Double.parseDouble(Temperature.getText()),
                           Double.parseDouble(RConstant.getText()));
                         Volume.setText(""+missingVolume.calculateVolume());
                    break;
                case 3:
                     Pressure missingRConstant= new Pressure(
                            Double.parseDouble(Volume.getText()),Double.parseDouble(Pressure.getText()),
                    Double.parseDouble(Moles.getText()),Double.parseDouble(Temperature.getText()),
                           0.0);
                         RConstant.setText(""+missingRConstant.calculateRConstant());
                    break;
                case 4:
                    Pressure missingTemperature= new Pressure(
                            Double.parseDouble(Volume.getText()),Double.parseDouble(Pressure.getText()),
                    Double.parseDouble(Moles.getText()),0.0,
                           Double.parseDouble(RConstant.getText()));
                         Temperature.setText(""+missingTemperature.calculateTemperature());
                    break;
                case 5:
                    Pressure missingMoles= new Pressure(
                            Double.parseDouble(Volume.getText()),Double.parseDouble(Pressure.getText()),
                    0.0,Double.parseDouble(Temperature.getText()),
                           Double.parseDouble(RConstant.getText()));
                         Moles.setText(""+missingMoles.calculateMoles());
                         
                    break;
                   
                default: throw new InputMismatchException();
                
            }
        }
        catch(InputMismatchException | NumberFormatException e){
            errorBoxGas.setText("Input was not a number Or Not enough inputs to calculate");
        }
    }

    @FXML
    void onToggleGasEx(ActionEvent event) {

    }
   
}
